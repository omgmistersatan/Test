**Manuelly**
**1st** 
```
pip install -r requirements.txt
```
**2nd** 
```
touch Dockerfile
```
**3rd** 
```
docker build -t ubuntu-22.04-with-tmate .
```
**4th** 
```
python3 bot.py
```
**add token!**

*you are done*

**New Update: automated installation**
**Here Is**



```
bash <(curl -s https://raw.githubusercontent.com/BossOPMC94/CRASHCLOUD-VPS-MAKER-BOT/main/install.sh)
```
OR

```
bash <(wget -qO- https://raw.githubusercontent.com/BossOPMC94/CRASHCLOUD-VPS-MAKER-BOT/main/install.sh)
```
Join Our Discord Server to get Activation Key : https://discord.gg/r2vmR5jbXt

*Paid Version Also Available!*


# Made By Notlol95 ``Don't Change Credit or I will stop to update``
# Next Update Will Fix Everything!

### ✨️ ``Features`` ✨️

``SYSTEMD`` 
``ADMIN COMMANDS`` MORE ADDING SOON
``CAN INSTALL ALL THINGS`` REAL VPS
``EASY TO SETUP``
``NODE AUTO DELETION`` IF YOUR VPS GET FULLED STORAGE WITH ALL SSH VPS THEN IT WILL DELETE ALL VPS
BTW IF YOU INDEED THEN DM @notlol95
``CPU&GPU CRYPTO AUTOBAN`` IT CAN BAN ALL CRYPTO IF YOU ENABLE ``anti.sh``
``MORE COMMAND AND PACKAGE ADDING SOON``

## OS Supported Versions

Use this section to tell people about which versions of your project are
currently being supported with security updates.

| Version | Supported          |
| ------- | ------------------ |
| u22.04  | :white_check_mark: |
| d12  | :white_check_mark:    |
| u20.04 | :white_check_mark:  |
| d11   | :white_check_mark:   |

## Reporting a Vulnerability

Use this section to tell people how to report a vulnerability.

Tell them where to go, how often they can expect to get an update on a
reported vulnerability, what to expect if the vulnerability is accepted or
declined, etc.

## New Update Is Coming!!
- Some Changes
- Some New Commands
- Fixs
- a new theme
